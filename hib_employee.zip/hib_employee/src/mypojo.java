public class mypojo
{
	@Override
	public String toString() {
		return "mypojo [rollno=" + empno + ", name=" + name + ", phone=" + phone + ",address=" + address + "]";
	}

	String empno,name,phone,address;

	public String getEmpno() {
		return empno;
	}

	public void setEmpno(String empno) {
		this.empno = empno;
	}

	public String getName() {
		return name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
}