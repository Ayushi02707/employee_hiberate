import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class part
{
	public static void main(String args[])throws Exception
	{
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss=sf.openSession();
		mypojo pojo=new mypojo();
		Scanner sc= new Scanner(System.in);
		
		
		
		
		int num;
		System.out.println("enter your choice");
		num=sc.nextInt();
	
		switch(num)
		{
		case 1:
			String empno, name, phone, address;
			System.out.println("Enter empno: ");
			empno=sc.next();
			System.out.println("Enter name: ");
			name=sc.next();
			System.out.println("Enter phoneno: ");
			phone=sc.next();
			System.out.println("Enter address: ");
			address=sc.next();
		pojo.setEmpno(empno);
		pojo.setName(name);
		pojo.setPhone(phone);
		pojo.setAddress(address);
		
		Transaction tx=ss.beginTransaction();
		ss.save(pojo);
		tx.commit();
		
	   Transaction tx1=ss.beginTransaction();
		Query q=ss.createQuery("from mypojo");
		  List list=q.list();
      System.out.println(list);
		
		List stud=q.list();
		Iterator it=stud.iterator();
		while(it.hasNext())
		{			pojo=(mypojo)it.next();
			System.out.println(pojo.getEmpno());
			System.out.println(pojo.getName());
			System.out.println(pojo.getPhone());
			System.out.println(pojo.getAddress());
		}
		break;
		
		case 2:
		Transaction tx2 = ss.beginTransaction();
		Query qq=ss.createQuery("from mypojo");
		System.out.println("Updating row ");
		System.out.println("Enter emp no for update");
		String empno1, name1, phone1, address1;

	     String empno11 = sc.next();
	     System.out.println("Enter name");
	     String	name11 = sc.next();
	     System.out.println("Enter phone no");
	     String	phone11 = sc.next();
         System.out.println("Enter address");
         String	address11 = sc.next();

		Query q4 = ss.createQuery("update mypojo set name=:n, phone=:p, address=:ad where empno=:e");
		q4.setParameter("n", name11);
		q4.setParameter("p", phone11);
		q4.setParameter("ad", address11);
		q4.setParameter("e", empno11 );

		int status1 = q4.executeUpdate();
		System.out.println(empno11  + " row updated " + status1);
		tx2.commit();
		break;
		
		case 3:
			
		Transaction tx3 = ss.beginTransaction();
		System.out.println("Enter emp no for deleted");
	     String empno1111 = sc.next();
	   
		Query q3=ss.createQuery("delete from mypojo where empno=:e ");  
		q3.setParameter("e", empno1111);
		int status2=q3.executeUpdate();
		System.out.println(empno1111  + " row deleted " + status2);
		tx3.commit();  
		break;
		
		case 4:
        Query q5=ss.createQuery("select count(empno) from mypojo");  
        System.out.println(q5);
        break;
   
    default:
    {
    	System.out.println("erooor");
    }
	}
	}
}

